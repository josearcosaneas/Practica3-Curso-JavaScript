/*
	Esta funcion solo muestra por pantalla la palabra que 
	se le pase como argumento

*/
function decirPalabra(palabra) {
  console.log(palabra);
}

// Llamamos a la funcion con un mensaje habitual
decirPalabra("Hola");
decirPalabra("a");
decirPalabra("Todos");
